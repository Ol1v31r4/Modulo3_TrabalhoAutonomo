--UPDATES
--update PACIENTE										--update da tabela paciente
--set paciente_cc = 432786801							--o que se quer actualizar
--where paciente_nome = 'Patricia'						--pertence a linha da coluna nome a designar

--update MEDICO
--set medico_especialidade = 'Otorrinolaringologia'	--de Otorrino para Otorrinolaringologia
--where medico_nome = 'Isabel'

--update RECEITA
--set receita_quantidade_levantada = '4'
--where receita_medicamento = 'Pregabalina'

--select * from LAB
--select * from MEDICAMENTO
--INSERT INTO Lab (lab_nome, medicamento_id) 
--VALUES ('TesteEmPEssoas', 10);

--select * from LAB
--delete from LAB
--where medicamento_id = 6

----- A -----
-- O nome, n�mero de cart�o do cidad�o e n�mero do sistema de sa�de de todos pacientes
select paciente_nome, paciente_cc, paciente_niss 
from PACIENTE

----- B -----
--As institui��es onde o m�dico Ernesto trabalha.

select instituicao_nome, medico_nome
from INSTITUICAO
inner join INSTITUICAO_MEDICO
on INSTITUICAO.instituicao_id = INSTITUICAO_MEDICO.instituicao_id
inner join MEDICO
on MEDICO.medico_cc = INSTITUICAO_MEDICO.medico_cc 
where MEDICO.medico_nome like '%Ernesto%'
order by INSTITUICAO.instituicao_nome


----- C -----
--O stock de todos os medicamentos da Farm�cia MedicamentosAqui
select sum(stock_quantidade) as Total, farmacia_nome 
from stock
inner join FARMACIA
on FARMACIA.farmacia_id = STOCK.farmacia_id
where farmacia_nome = 'MedicamentosAQui'
group by farmacia_nome


----- D -----
-- As receitas totalmente levantadas, parcialmente adquiridas ou por adquirir do paciente Orlando
select PACIENTE.paciente_niss, paciente_nome, receita_medicamento, receita_quantidade_levantada, receita_quantidade_total 
from PACIENTE
inner join RECEITA
on RECEITA.paciente_niss = PACIENTE.paciente_niss
where PACIENTE.paciente_niss = '358298400257'

----- E -----
-- As receitas que o m�dico Faustino introduziu para o paciente Ulisses, bem como a designa��o, quantidade e posologia de cada medicamento.
select * 
from MEDICO
inner join RECEITA
on RECEITA.medico_cc = MEDICO.medico_cc
inner join PACIENTE
on PACIENTE.paciente_niss = RECEITA.paciente_niss
where MEDICO.medico_nome = 'Faustino' and PACIENTE.paciente_nome = 'Orlando'

----- F -----
-- Os medicamentos que o m�dico Ernesto introduziu em receitas, distribu�dos por quantidade, nos �ltimos 5 anos
select * 
from RECEITA
inner join MEDICO
on RECEITA.medico_cc = MEDICO.medico_cc
where MEDICO.medico_cc = '123456789' and year(receita_data) <= DATEADD(yy, -5, GETDATE())

----- G -----
-- Os medicamentos que nunca foram utilizados em receitas
select medicamento_id, medicamento_designacao, medicamneto_descricao, medicamento_comparticipado, medicamento_validade, medicamento_apresentacao, MEDICAMENTO.receitas_id from MEDICAMENTO
left join RECEITA
on RECEITA.receitas_id = MEDICAMENTO.receitas_id
where MEDICAMENTO.receitas_id is null


----- H -----
-- O medicamento mais levantado em farm�cias
select top 1 sum(receita_quantidade_levantada) as mais_levantado, receitas_id, receita_medicamento
from RECEITA
where receita_quantidade_levantada <= 4
group by receita_medicamento, receitas_id
order by mais_levantado desc


----- I -----
-- As receitas cuja data de validade j� expirou e n�o foram levantadas
select * from RECEITA
where receita_quantidade_levantada = '0' and receita_validade <= GETDATE()

----- J -----
-- O laborat�rio de fabrico que disponibiliza mais medicamentos
select top 1 sum(stock_quantidade) as total_quantidade, lab_nome  
from STOCK
inner join MEDICAMENTO
on MEDICAMENTO.medicamento_id = STOCK.medicamento_id
inner join LAB
on LAB.medicamento_id = STOCK.medicamento_id
group by lab_nome
order by total_quantidade desc