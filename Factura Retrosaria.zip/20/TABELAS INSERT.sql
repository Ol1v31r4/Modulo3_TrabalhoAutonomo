go
use RETROSARIA

------ CLIENTES -------

insert into CLIENTE (cliente_nome, cliente_morada, cliente_telefone)
			  values ('Andre Guerreiro', 'R Desid�rio Bessa 9', '966123123');
insert into CLIENTE (cliente_nome, cliente_morada, cliente_telefone)
			  values ('Luis Diogo', 'Avenida Jo�o Cris�stomo 51', '933456189');
insert into CLIENTE (cliente_nome, cliente_morada, cliente_telefone)
			  values ('Filipe Soares', 'Avenida Rep�blica 43', '962786680');
insert into CLIENTE (cliente_nome, cliente_morada, cliente_telefone)
			  values ('Bruno Leal', 'Avenida Miguel Bombarda 42', '913900655');
insert into CLIENTE (cliente_nome, cliente_morada, cliente_telefone)
			  values ('Margarida Chickenstoc', 'Rua Diogo C�o 13', '912222564');


----- LOJA -----

insert into LOJA (loja_nome, loja_morada, loja_telefone, loja_zona)
		  values ('Loja 1', 'R S�o Sebasti�o 32', '913639106', 'Lisboa');
insert into LOJA (loja_nome, loja_morada, loja_telefone, loja_zona)
		  values ('Loja 2', 'Avenida Marqu�s Tomar 19', '915028694', 'Oeiras');
insert into LOJA (loja_nome, loja_morada, loja_telefone, loja_zona)
	      values ('Loja 3', 'R Germana T�nger 94', '961307889', 'Cascais');
insert into LOJA (loja_nome, loja_morada, loja_telefone, loja_zona)
	      values ('Loja 4', 'Avenida For�as Armadas 26', '968274319', 'Estoril');
insert into LOJA (loja_nome, loja_morada, loja_telefone, loja_zona)
   	      values ('Loja 5', 'Avenida J�lio Dinis 36', '912310942', 'Lisboa')


------ FORNECEDOR -------

insert into FORNECEDOR (fornecedor_nome, fornecedor_zona)
				values ('Fornecedor Da Linha', 'Oeiras')
insert into FORNECEDOR (fornecedor_nome, fornecedor_zona)
				values ('Fornecedor Galinha', 'Oeiras')
insert into FORNECEDOR (fornecedor_nome, fornecedor_zona)
				values ('Fornecedor Tinha', 'Lisboa')
insert into FORNECEDOR (fornecedor_nome, fornecedor_zona)
				values ('Fornecedor Inha', 'Cascais')
insert into FORNECEDOR (fornecedor_nome, fornecedor_zona)
				values ('Fornecedor Tinha', 'Lisboa')


----- FORNECEDOR_RETROSARIA --------

insert into FORNECEDOR_LOJA (fornecedor_id, loja_id)
					 values ('1', '1')			 
insert into FORNECEDOR_LOJA (fornecedor_id, loja_id)
				     values ('5', '2')			 
insert into FORNECEDOR_LOJA (fornecedor_id, loja_id)
				     values ('5', '4')			 
insert into FORNECEDOR_LOJA (fornecedor_id, loja_id)
				     values ('5', '1')			 
insert into FORNECEDOR_LOJA (fornecedor_id, loja_id)
					 values ('1', '2')			 
insert into FORNECEDOR_LOJA (fornecedor_id, loja_id)
					 values ('4', '4')			 
insert into FORNECEDOR_LOJA (fornecedor_id, loja_id)
					 values ('3', '1')			 
insert into FORNECEDOR_LOJA (fornecedor_id, loja_id)
					 values ('2', '1')			 
insert into FORNECEDOR_LOJA (fornecedor_id, loja_id)
				     values ('3', '5')			 
insert into FORNECEDOR_LOJA (fornecedor_id, loja_id)
				     values ('1', '5')			 
insert into FORNECEDOR_LOJA (fornecedor_id, loja_id)
				     values ('2', '5')			
insert into FORNECEDOR_LOJA (fornecedor_id, loja_id)
				     values ('1', '3')


----- PECAS ------

insert into PECAS (pecas_tipo, pecas_tamanho, pecas_cor)
		   values ('Camisola', 'XL', 'Vermelho');
insert into PECAS (pecas_tipo, pecas_tamanho, pecas_cor)
		   values ('Casaco', 'M', 'Azul');
insert into PECAS (pecas_tipo, pecas_tamanho, pecas_cor)
		   values ('Calca', 'S', 'Verde');
insert into PECAS (pecas_tipo, pecas_tamanho, pecas_cor)
		   values ('Boxer', 'XS', 'Vermelho e Branco');
insert into PECAS (pecas_tipo, pecas_tamanho, pecas_cor)
		   values ('Camisa', 'L', 'Encarnado');
insert into PECAS (pecas_tipo, pecas_tamanho, pecas_cor)
		   values ('Blazer', 'M', 'Branco');
insert into PECAS (pecas_tipo, pecas_tamanho, pecas_cor)
		   values ('Vestido', 'M', 'Preto');
insert into PECAS (pecas_tipo, pecas_tamanho, pecas_cor)
		   values ('Chapeu', 'L', 'Verde');
insert into PECAS (pecas_tipo, pecas_tamanho, pecas_cor)
		   values ('Cachecol', 's', 'Salm�o');
insert into PECAS (pecas_tipo, pecas_tamanho, pecas_cor)
		   values ('Jardineira', 'XXXXL', 'Rosa');
insert into PECAS (pecas_tipo, pecas_tamanho, pecas_cor)
		   values ('Meias', 's', 'Amarelo e Preto');
insert into PECAS (pecas_tipo, pecas_tamanho, pecas_cor)
		   values ('Camisa manga Curta', 'XXXXL', 'Laranja e Branca');



----- ARRANJO ------

insert into ARRANJO (arranjo_tipo, arranjo_preco) 
			 values ('Coser', 3);
insert into ARRANJO (arranjo_tipo, arranjo_preco) 
			 values ('Bainhas', 5);
insert into ARRANJO (arranjo_tipo, arranjo_preco) 
		     values ('Colocar Fecho', 8);
insert into ARRANJO (arranjo_tipo, arranjo_preco) 
		     values ('Apertar', 7);
insert into ARRANJO (arranjo_tipo, arranjo_preco) 
		     values ('Alargar', 10);
insert into ARRANJO (arranjo_tipo, arranjo_preco) 
			 values ('Bot�es', 4);



------ ARRANJO_COSTUM ------

insert into ARRANJO_COSTUM (arranjo_costumizado, arranjo_costumizado_preco)
					values ('Missangas', 45);
insert into ARRANJO_COSTUM (arranjo_costumizado, arranjo_costumizado_preco)
					values ('Contas', 55);
insert into ARRANJO_COSTUM (arranjo_costumizado, arranjo_costumizado_preco)
					values ('Bordados', 40);
insert into ARRANJO_COSTUM (arranjo_costumizado, arranjo_costumizado_preco)
					values ('Estampagem', 25);
insert into ARRANJO_COSTUM (arranjo_costumizado, arranjo_costumizado_preco)
					values ('Transforma��es', 70);


------ SERVICO ------
						--Chicken        Loja 1   Vestido     Bainha																	Nao
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_id, servico_comentario, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('912222564',		'1' ,		 7,      4,          'Sensivel', '2023-06-1',       '2023-06-20',          1);
						--Soares         Loja 1    Havaina     Estampar																			Sim
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_costum_id, servico_comentario, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('962786680',		'1' ,		 12,       4,		'Estampar um Drag�o','2023-06-15',		 '2023-06-17',       2);			
						--Leal         Loja 2      Cal�as		Coser	 											Nao
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_id, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('913900655',		'2' ,	  8,      1,          '2023-06-15',       '2023-06-29',          1);			
						--Luis         Loja 3	Jardineiras  Coser	 																	Nao
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_id, servico_comentario, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('933456189',		'3' ,	  10,      1,       'Rasgou a baixar',		'2023-06-21',    '2023-07-2',        1);			
						--Andre         Loja 2    Boxers     Bainha		 												Nao
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_id, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('966123123',		'2' ,	  4,       1,          '2023-06-23',       '2023-06-28',          1);			
						--Soares        Loja 4    Meias    	missangas																		Sim
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_costum_id, servico_comentario, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('962786680',		'4' ,	  11,       1,				'Pressa',		'2023-06-01',			 '2023-06-06',          2);			
						--Chicken       Loja 4  cachecol  bordados																		Sim
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_costum_id, servico_comentario, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('912222564',		'4' ,	  9,       3,			'Bordar Hello Kitty',		'2023-05-21',	'2023-05-25',          2);			
						--Leal         Loja 1    Camisa     Alargar	 											Nao
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_id, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('913900655',		'1' ,	  5,       5,		 '2023-05-29',			'2023-06-10',		'1');			
						--Andre          Loja 5   Blazer    Coser		 																Nao
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_id, servico_comentario, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('966123123',		'1' ,	  6,       1,         'Estampar um Tigre', '2023-06-04',       '2023-06-29',       1);			
						--Luis           Loja 5  Vestido     Fecho		 																 sim
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_id, servico_comentario, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('933456189',		'5' ,	 7,        3,      	'Sensivel', '2023-06-11',    '2023-06-14',          2);	
						--Chicken         Loja 5  Meias     coser		 																 sim
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_id, servico_comentario, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('912222564',		'5' ,	 4,        1,      	'Rasgou por uso',   '2023-06-14',    '2023-06-16',               2);			
						--Leal           Loja 1  Blazer     Coser																	Nao
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_id, servico_comentario, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('913900655',		'1' ,	 6,         1,       'Descoseu a andar', '2023-06-1',       '2023-06-20',            1);
						--Luis        Loja 1     Meias     Coser																	Nao
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_id, servico_comentario, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('933456189',		'1' ,		 4,      1,        'Unha rompeu meia', '2023-06-1',       '2023-06-17',          1);
						--Leal         Loja 1    Camisa     Alargar	 											Nao
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_id, servico_comentario , servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('913900655',		'5' ,	  5,		 1,				 'Sensivel'				,'2023-06-14',			'2023-06-30',		'1');			
						--Chicken       Loja 4  vestido  bordados																		Sim
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_costum_id, servico_comentario, servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('912222564',		'5' ,	  7,			  1,			'Sensivel',		'2023-06-11',	'2023-06-29',          1);			
						--Leal         Loja 1    Camisa     Alargar	 											Nao
insert into SERVICO (cliente_telefone, loja_id,  pecas_id, arranjo_costum_id, servico_comentario , servico_data_inicio, servico_data_fim, servico_urgente)
			 values ('913900655',		'2' ,	  5,			 4,			'Estampar um Mocho'		,'2023-06-14',			'2023-06-17',		'2');	



----- ORCAMENtO ------
select * from orcamento
insert into ORCAMENTO (servico_id, orcamento_total, orcamento_decisao)
			   values (   '2',			'50',				'1');
insert into ORCAMENTO (servico_id, orcamento_total, orcamento_decisao)
			   values (   '6',			'90',				'0');
insert into ORCAMENTO (servico_id, orcamento_total, orcamento_decisao)
			   values (   '7',			'80',				'0');
insert into ORCAMENTO (servico_id, orcamento_total, orcamento_decisao)
			   values (   '15',			'45',				'1');
insert into ORCAMENTO (servico_id, orcamento_total, orcamento_decisao)
			   values (   '16',			'50',				'1');


----- PAGAMENTO ------
select * from pagamento
insert into PAGAMENTO (servico_id, pagamento_total, pagamento_aceite)
			   values (		'1',	   '7',			   '1');
insert into PAGAMENTO (servico_id, orcamento_id, pagamento_total, pagamento_aceite)
			   values (		'2',		'1',	       '50',		    '1');
insert into PAGAMENTO (servico_id, pagamento_total, pagamento_aceite)
			   values (		'3',		'3',				'1');
insert into PAGAMENTO (servico_id, pagamento_total, pagamento_aceite)
			   values (		'4',			'3',				'0');
insert into PAGAMENTO (servico_id, pagamento_total, pagamento_aceite)
			   values (		'5',			'3',				'1');
insert into PAGAMENTO (servico_id, orcamento_id, pagamento_total, pagamento_aceite)
			   values (		'6',		 '2',			'90',			'0');
insert into PAGAMENTO (servico_id, orcamento_id, pagamento_total, pagamento_aceite)
			   values (		'7',		 '3',			'80',			'1');
insert into PAGAMENTO (servico_id, pagamento_total, pagamento_aceite)
			   values (		'8',		'10',				'1');
insert into PAGAMENTO (servico_id, pagamento_total, pagamento_aceite)
			   values (		'9',		'3',				'1');
insert into PAGAMENTO (servico_id, pagamento_total, pagamento_aceite)
			   values (		'10',		'16',				'1');
insert into PAGAMENTO (servico_id, pagamento_total, pagamento_aceite)
			   values (		'11',		'6',				'1');
insert into PAGAMENTO (servico_id, pagamento_total, pagamento_aceite)
			   values (		'12',		'3',				'0');
insert into PAGAMENTO (servico_id, pagamento_total, pagamento_aceite)
			   values (		'13',		'3',				'1');
insert into PAGAMENTO (servico_id, pagamento_total, pagamento_aceite)
			   values (		'14',			'3',				'0');
insert into PAGAMENTO (servico_id, orcamento_id, pagamento_total, pagamento_aceite)
			   values (		'15',		'4',			'45',			'1');
insert into PAGAMENTO (servico_id, orcamento_id, pagamento_total, pagamento_aceite)
			   values (		'16',		'5',			'50',			'0');



------ DEVOLUCAO ------

insert into DEVOLUCAO (servico_id, pagamento_id, devolucao_pagamento)
			   values (    '4',			 '4',			'3');
insert into DEVOLUCAO (servico_id, pagamento_id, devolucao_pagamento)
			   values (   '6',		    '6',			'90');
insert into DEVOLUCAO (servico_id, pagamento_id, devolucao_pagamento)
			   values (   '12',			 '12',			'3');
insert into DEVOLUCAO (servico_id, pagamento_id, devolucao_pagamento)
			   values (   '14',			'14',			'3');
insert into DEVOLUCAO (servico_id, pagamento_id, devolucao_pagamento)
			   values (	  '16',			'16',			'50');
