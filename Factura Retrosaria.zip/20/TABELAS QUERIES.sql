go
use RETROSARIA

------ QUERIES ------

--a. Todas as lojas da zona de Lisboa

select * from LOJA
where loja_zona = 'Lisboa'

--b. Informa��o sobre os trabalhos n�o conclu�dos, por ordem crescente de data de in�cio

select servico_id, arranjo_id, arranjo_costum_id, servico_data_inicio,servico_data_fim from SERVICO
where servico_data_fim >= GETDATE()
order by servico_data_inicio asc

--c. Os trabalhos urgentes aceites, solicitados pelo cliente

select servico_id, cliente_telefone, servico_urgente from SERVICO
where servico_urgente = 2

--d. O arranjo mais caro

select MAX(arranjo_costumizado_preco) as Arranjo_Costum_Mais_Caro, MAX(arranjo_preco) as Arranjo_Mais_Caro
from ARRANJO, ARRANJO_COSTUM

--e. O custo do arranjo das pe�as, por tipo de arranjo

select arranjo_tipo, arranjo_preco, pecas_tipo
from ARRANJO, PECAS
order by arranjo_preco

--f. O tipo de arranjo que nunca foi pedido

select servico_id, cliente_telefone, loja_id, pecas_id, SERVICO.arranjo_id 
from SERVICO
left join ARRANJO
on ARRANJO.arranjo_id = SERVICO.arranjo_id
where ARRANJO.arranjo_id is null

--g. A loja que tem mais pedidos entregues  -----XX-----

select top 1 LOJA.loja_id, loja_morada, loja_nome 
from SERVICO
inner join LOJA
on SERVICO.loja_id = LOJA.loja_id
group by LOJA.loja_id, loja_morada, loja_nome
order by  count(SERVICO.loja_id) desc

--h. A quantidade de pe�as arranjadas da loja 1, dos �ltimos 7 dias

select SERVICO.loja_id, pecas_id, servico_data_inicio, servico_data_fim 
from SERVICO
left join LOJA
on SERVICO.loja_id = LOJA.loja_id
where servico_data_fim between '2023-06-10' and '2023-06-19' and SERVICO.loja_id = 1
group by SERVICO.loja_id, pecas_id, servico_data_inicio, servico_data_fim
order by servico_data_fim

--i. Os trabalhos que incluem arranjos de camisas e que ainda n�o foram levantados

select *, pecas_tipo from servico
inner join PECAS
on SERVICO.pecas_id = PECAS.pecas_id
where pecas_tipo like '%camisa%' and servico_data_fim >= getdate()

--j. Os trabalhos que n�o foram pagos e foram devolvidos

select * from PAGAMENTO 
inner join DEVOLUCAO
on PAGAMENTO.pagamento_id = DEVOLUCAO.pagamento_id
where pagamento_aceite = 0

--k. Os pedidos urgentes que incluem pe�as com pelo menos 2 cores diferentes

select servico_id, pecas_tipo, pecas_cor ,servico_urgente from servico
inner join PECAS
on SERVICO.pecas_id = PECAS.pecas_id
where pecas_cor like '% e %' and servico_urgente = '2'

--l. Os trabalhos n�o devolvidos com a indica��o nas observa��es de que s�o pe�as sens�veis

select SERVICO.servico_id, arranjo_id, arranjo_costum_id, servico_comentario, pagamento_aceite from SERVICO
inner join PAGAMENTO
on PAGAMENTO.servico_id = SERVICO.servico_id
inner join DEVOLUCAO
on DEVOLUCAO.servico_id = SERVICO.servico_id
where servico_comentario like '%sensivel%' and pagamento_aceite = '1'


--m. Os trabalhos urgentes que foram mais caros do que todos os trabalhos n�o urgentes.

--ERRADO
select SERVICO.servico_id, ARRANJO_COSTUM.arranjo_costumizado_preco, servico_urgente, pagamento_total 
from SERVICO 
inner join ARRANJO on ARRANJO.arranjo_id = SERVICO.arranjo_id
inner join ARRANJO_COSTUM on ARRANJO_COSTUM.arranjo_costum_id = SERVICO.arranjo_costum_id
inner join PAGAMENTO on SERVICO.servico_id = PAGAMENTO.servico_id
where servico_urgente = '2'  
and ARRANJO_COSTUM.arranjo_costumizado_preco >= ARRANJO.arranjo_preco
group by SERVICO.servico_id, ARRANJO.arranjo_preco , ARRANJO_COSTUM.arranjo_costumizado_preco , servico_urgente, pagamento_total



--n. A loja que teve menos valor faturado no �ltimo m�s.

select top 1 SERVICO.loja_id as Loja_ID, MIN(pagamento_total) as Pagamentos
from SERVICO
inner join PAGAMENTO
on SERVICO.servico_id = PAGAMENTO.servico_id
where servico_data_fim between '2023-05-19' and '2023-06-19' and pagamento_aceite = 1
group by SERVICO.loja_id, pagamento_total
