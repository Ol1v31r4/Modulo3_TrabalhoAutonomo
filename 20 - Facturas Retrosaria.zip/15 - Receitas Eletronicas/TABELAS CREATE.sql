create database RECEITAS_ELETRONICAS
GO

--DROP TABLES COMENTADAS NO FINAL POR ORDEM

use RECEITAS_ELETRONICAS

--1X 
create table MEDICO
(
medico_nome varchar(20) not null,
medico_telefone varchar(9) not null,
medico_especialidade varchar (25) not null, 
medico_cc varchar(9) PRIMARY KEY not null,				-- PRIMARY KEY
);

--2X
create table PACIENTE
(
paciente_nome varchar (20) not null,
paciente_morada varchar (max) not null,
paciente_cc varchar (9) not null,
paciente_niss varchar (12) PRIMARY KEY not null,  -- PRIMARY KEY
paciente_nascimento date not null,
);


--3X
create table INSTITUICAO
(
instituicao_id int PRIMARY KEY IDENTITY (1, 1) not null,
instituicao_nome varchar (max) not null, 
);


--4X
create table INSTITUICAO_MEDICO
(
instituicao_medico_id int PRIMARY KEY IDENTITY (1, 1) not null,
instituicao_id int FOREIGN KEY REFERENCES INSTITUICAO(instituicao_id) not null,
medico_cc varchar (9) FOREIGN KEY REFERENCES MEDICO (medico_cc) not null,
);


--5X 
create table RECEITA 
(
receitas_id int PRIMARY KEY IDENTITY (1, 1) not null,
paciente_niss varchar(12) FOREIGN KEY REFERENCES PACIENTE (paciente_niss) not null,
medico_cc varchar (9) FOREIGN KEY REFERENCES MEDICO (medico_cc) not null,
receita_data date not null, 
receita_validade date not null, --- pk ?
receita_medicamento varchar (max) not null,
receita_posologia varchar(max) not null,
receita_quantidade_total     int not null,
receita_quantidade_levantada int not null,
);


--6X
create table MEDICAMENTO
(
medicamento_id int PRIMARY KEY IDENTITY (1, 1) not null,
medicamento_designacao varchar(50) not null,
medicamneto_descricao varchar (50) not null,
medicamento_comparticipado bit not null,
medicamento_validade date not null,
medicamento_apresentacao varchar(50) not null, --xarope, comprimido, pomada
receitas_id int FOREIGN KEY REFERENCES RECEITA(receitas_id),
);


--7X
create table FARMACIA
(
farmacia_id int PRIMARY KEY IDENTITY (1, 1) not null,
farmacia_nome varchar(25) not null,
farmacia_morada varchar(50) not null,
farmacia_telefone varchar(9) not null,
);


--8X
create table STOCK
(
stock_id int PRIMARY KEY IDENTITY (1, 1) not null,
farmacia_id int FOREIGN KEY REFERENCES FARMACIA (farmacia_id) not null,
medicamento_id int FOREIGN KEY REFERENCES MEDICAMENTO (medicamento_id) not null,
stock_quantidade int not null,
);

--9X UM laboratoria FAZ UM medicamento
create table LAB
(
lab_id int PRIMARY KEY IDENTITY (1, 1) not null,
lab_nome varchar(50) not null,
medicamento_id int FOREIGN KEY REFERENCES MEDICAMENTO(medicamento_id) not null,
);




--DROPS POR ORDEM
--drop table INSTITUICAO_MEDICO
--drop table INSTITUICAO
--drop table LAB
--drop table STOCK
--drop table FARMACIA
--drop table MEDICAMENTO
--drop table RECEITA
--drop table MEDICO
--drop table PACIENTE



