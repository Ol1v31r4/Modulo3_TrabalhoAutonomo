create database RETROSARIA

go
use RETROSARIA

--DROP TABLES COMENTADAS POR ORDEM NO FINAL

--1X
create table CLIENTE
(
cliente_nome varchar (25) not null,
cliente_morada varchar (50) not null,
cliente_telefone varchar (9) PRIMARY KEY not null,
);


--2X
create table LOJA
(
loja_id int  PRIMARY KEY IDENTITY (1, 1) not null,
loja_nome varchar (25) not null,
loja_morada varchar (50) not null,
loja_telefone varchar(9)not null,
loja_zona varchar (25) not null,
);

--3X
create table FORNECEDOR
(
fornecedor_id int PRIMARY KEY IDENTITY (1, 1) not null,
fornecedor_nome varchar(50) not null,
fornecedor_zona varchar (50) not null,
);

--4X
create table FORNECEDOR_LOJA
(
inventario_id int PRIMARY KEY IDENTITY (1, 1) not null,
fornecedor_id int FOREIGN KEY REFERENCES FORNECEDOR (fornecedor_id) not null,
loja_id int FOREIGN KEY REFERENCES LOJA(loja_id) not null,
);

--5X
create table PECAS 
(
pecas_id int PRIMARY KEY IDENTITY (1,1) not null,
pecas_tipo varchar (25) not null,
pecas_tamanho varchar (5) not null,
pecas_cor varchar (20) not null,
);

--6X
create table ARRANJO
(
arranjo_id int PRIMARY KEY IDENTITY (1, 1) not null,
arranjo_tipo varchar (25) not null,
arranjo_preco int not null,
);

--7X
create table ARRANJO_COSTUM
(
arranjo_costum_id int PRIMARY KEY IDENTITY (1, 1) not null,
arranjo_costumizado varchar(max) not null,
arranjo_costumizado_preco int not null,
);

--8X
create table SERVICO
(
servico_id int PRIMARY KEY IDENTITY (1, 1) not null,
cliente_telefone varchar (9) FOREIGN KEY REFERENCES CLIENTE(cliente_telefone) not null, 
loja_id int FOREIGN KEY REFERENCES LOJA(loja_id) not null,
pecas_id int FOREIGN KEY REFERENCES PECAS(pecas_id) not null,
arranjo_id int FOREIGN KEY REFERENCES ARRANJO(arranjo_id),
arranjo_costum_id int FOREIGN KEY REFERENCES ARRANJO_COSTUM(arranjo_costum_id),
servico_comentario varchar (max), 
servico_data_inicio Date not null,
servico_data_fim Date not null,
servico_urgente int not null,
);

--9X
create table ORCAMENTO
(
orcamento_id int PRIMARY KEY IDENTITY (10, 1) not null,
servico_id int FOREIGN KEY REFERENCES SERVICO(servico_id) not null,
orcamento_total int not null,
orcamento_decisao bit not null,
);


--10X
create table PAGAMENTO
(
pagamento_id INT PRIMARY KEY IDENTITY (1, 1) not null,
servico_id int FOREIGN KEY REFERENCES SERVICO(servico_id),
orcamento_id int FOREIGN KEY REFERENCES ORCAMENTO(orcamento_id), 
pagamento_total varchar(50) not null,  
pagamento_aceite bit not null,
);


--11X
create table DEVOLUCAO
(
devolucao_id int PRIMARY KEY IDENTITY (1, 1) not null,
servico_id int FOREIGN KEY REFERENCES SERVICO(servico_id) not null,
pagamento_id int FOREIGN KEY REFERENCES PAGAMENTO(pagamento_id) not null,
devolucao_pagamento int not null,
);



--drop table SERVICO
--drop table FORNECEDOR_LOJA
--drop table CLIENTE
--drop table LOJA
--drop table FORNECEDOR
--drop table PECAS
--drop table ARRANJO_COSTUM
--drop table ARRANJO
--drop table ORCAMENTO
--drop table PAGAMENTO
--drop table DEVOLUCAO
