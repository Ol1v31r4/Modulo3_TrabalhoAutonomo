go
use RECEITAS_ELETRONICAS

--X
--TABLE MEDICO
insert into MEDICO (medico_nome, medico_telefone, medico_especialidade, medico_cc)
			values ('Ernesto', '919299001', 'Dermatologia', '123456789');
insert into MEDICO (medico_nome, medico_telefone, medico_especialidade, medico_cc)
			values ('Faustino', '919312934', 'Cardiologia', '456789123');
insert into MEDICO (medico_nome, medico_telefone, medico_especialidade, medico_cc)
			values ('Isabel', '919357908', 'Otorrino', '789012345');
insert into MEDICO (medico_nome, medico_telefone, medico_especialidade, medico_cc)
			values ('Paula', '966152974', 'Gastrenterologia', '901234567');
insert into MEDICO (medico_nome, medico_telefone, medico_especialidade, medico_cc)
			values ('Elena', '969314044', 'Imunoalergologia', '567890123');

--X
--PACIENTE
insert into PACIENTE (paciente_nome, paciente_morada, paciente_cc, paciente_niss, paciente_nascimento)
			  values ('Orlando', 'R Desid�rio Bessa 9', '546123123', '358298400257', '1983-11-24');
insert into PACIENTE (paciente_nome, paciente_morada, paciente_cc, paciente_niss, paciente_nascimento)
			  values ('Ulisses', 'Avenida Jo�o Cris�stomo 51', '873456189', '549435529756', '1986-04-29');
insert into PACIENTE (paciente_nome, paciente_morada, paciente_cc, paciente_niss, paciente_nascimento)
			  values ('Patricia', 'Avenida Rep�blica 43', '43278680', '402712171306', '1982-06-14');
insert into PACIENTE (paciente_nome, paciente_morada, paciente_cc, paciente_niss, paciente_nascimento)
			  values ('Danielle', 'Avenida Miguel Bombarda 42', '453900655', '533914307010', '1977-01-01');
insert into PACIENTE (paciente_nome, paciente_morada, paciente_cc, paciente_niss, paciente_nascimento)
			  values ('Andre', 'Rua Diogo C�o 13', '212222564', '182906022963', '1989-06-30');

--X
--INSTITUI��ES
insert into INSTITUICAO (instituicao_nome)
				 values ('Hospital Santa Maria');
insert into INSTITUICAO (instituicao_nome)
				 values ('Hospital Julio de Matos');
insert into INSTITUICAO (instituicao_nome)
				 values ('Hospital Miguel Bombarda');
insert into INSTITUICAO (instituicao_nome)
				 values ('Hospital Publico de Cascais');
insert into INSTITUICAO (instituicao_nome)
				 values ('Hospital da Luz de Oeiras');

--X
--INSTITUICAO_MEDICO
insert into INSTITUICAO_MEDICO (instituicao_id, medico_cc)
                        values (2 , 123456789);
insert into INSTITUICAO_MEDICO (instituicao_id, medico_cc)
                        values (4 , 123456789);
insert into INSTITUICAO_MEDICO (instituicao_id, medico_cc)
                        values (3 , 456789123);
insert into INSTITUICAO_MEDICO (instituicao_id, medico_cc)
                        values (5 , 456789123);
insert into INSTITUICAO_MEDICO (instituicao_id, medico_cc)
                        values (2 , 567890123);
insert into INSTITUICAO_MEDICO (instituicao_id, medico_cc)
                        values (3 , 567890123);
insert into INSTITUICAO_MEDICO (instituicao_id, medico_cc)
                        values (1 , 567890123);
insert into INSTITUICAO_MEDICO (instituicao_id, medico_cc)
                        values (4 , 789012345);
insert into INSTITUICAO_MEDICO (instituicao_id, medico_cc)
                        values (1 , 789012345);
insert into INSTITUICAO_MEDICO (instituicao_id, medico_cc)
                        values (5 , 901234567);
insert into INSTITUICAO_MEDICO (instituicao_id, medico_cc)
                        values (2 , 901234567);
insert into INSTITUICAO_MEDICO (instituicao_id, medico_cc) 
						values (3 , 901234567);
select * from MEDICO
select * from PACIENTE
--X 
--RECEITAS																																																							  --T	--L			
insert into RECEITA (paciente_niss, medico_cc, receita_data, receita_validade, receita_medicamento, receita_posologia, receita_quantidade_total, receita_quantidade_levantada) 
			values ('358298400257', '456789123','2022-07-12', '2023-07-31', 'Ben-U-Ron', '2x ao Dia', '4', '2');     --Faustino para Orlando
insert into RECEITA (paciente_niss, medico_cc, receita_data, receita_validade, receita_medicamento, receita_posologia, receita_quantidade_total, receita_quantidade_levantada) 
			values ('358298400257', '456789123','2022-07-12', '2023-07-31', 'Omeprazol', '2x ao Dia', '4', '2');     --Faustino para Orlando
insert into RECEITA (paciente_niss, medico_cc, receita_data, receita_validade, receita_medicamento, receita_posologia, receita_quantidade_total, receita_quantidade_levantada) 
			values ('402712171306', '456789123','2022-07-12', '2023-07-31', 'Alprazolam', '2x ao Dia', '2', '0');    --Faustino para Patricia
insert into RECEITA (paciente_niss, medico_cc, receita_data, receita_validade, receita_medicamento, receita_posologia, receita_quantidade_total, receita_quantidade_levantada) 
			values ('402712171306', '456789123','2023-09-10', '2022-02-10', 'Pregabalina', '1x ao Dia', '4', '4');   --Elena para Patricia
insert into RECEITA (paciente_niss, medico_cc, receita_data, receita_validade, receita_medicamento, receita_posologia, receita_quantidade_total, receita_quantidade_levantada) 
			values ('533914307010', '567890123', '2023-01-03','2021-04-05', 'Alprazolam', '1x ao Dia', '2', '1');    --Isabel para Danielle
insert into RECEITA (paciente_niss, medico_cc, receita_data, receita_validade, receita_medicamento, receita_posologia, receita_quantidade_total, receita_quantidade_levantada) 
			values ('549435529756', '901234567','2021-06-16', '2021-09-21', 'Fluoxetina', '2x ao Dia', '4', '4');    --Paula para Ulisses
insert into RECEITA (paciente_niss, medico_cc, receita_data, receita_validade, receita_medicamento, receita_posologia, receita_quantidade_total, receita_quantidade_levantada) 
			values ('549435529756', '123456789', '2022-04-09', '2023-10-29', 'Omeprazol', '1x ao Dia', '4', '1');    --Ernesto para Ulisses
insert into RECEITA (paciente_niss, medico_cc, receita_data, receita_validade, receita_medicamento, receita_posologia, receita_quantidade_total, receita_quantidade_levantada) 
			values ('182906022963', '123456789', '2022-04-09', '2023-10-29', 'Amoxicilina', '1x ao Dia', '1', '1');  --Ernesto para Andre
insert into RECEITA (paciente_niss, medico_cc, receita_data, receita_validade, receita_medicamento, receita_posologia, receita_quantidade_total, receita_quantidade_levantada) 
			values ('182906022963', '123456789', '2022-04-09', '2023-10-29', 'Fluoxetina', '1x ao Dia', '4', '1');   --Ernesto para Andre
insert into RECEITA (paciente_niss, medico_cc, receita_data, receita_validade, receita_medicamento, receita_posologia, receita_quantidade_total, receita_quantidade_levantada) 
			values ('533914307010', '123456789', '2023-01-03','2021-04-05', 'BiResp', '1x ao Dia', '2', '1');        --Isabel para Danielle
				


--MEDICAMENTOS																																																										    R_id  stock_id				
insert into MEDICAMENTO (medicamento_designacao, medicamneto_descricao, medicamento_comparticipado, medicamento_validade, medicamento_apresentacao, receitas_id)
				values ('Alprazolam','Ansiolitico', '1', '2027-04-05', 'Comprimido', '3');
insert into MEDICAMENTO (medicamento_designacao, medicamneto_descricao, medicamento_comparticipado, medicamento_validade, medicamento_apresentacao, receitas_id)
				values ('Amoxicilina','Anti-Biotico', '1', '2028-04-01', 'Comprimido', '5');
insert into MEDICAMENTO (medicamento_designacao, medicamneto_descricao, medicamento_comparticipado, medicamento_validade, medicamento_apresentacao, receitas_id)
				values ('Fluoxetina','Antidepressivo', '1', '2030-10-20', 'Comprimido', '4');
insert into MEDICAMENTO (medicamento_designacao, medicamneto_descricao, medicamento_comparticipado, medicamento_validade, medicamento_apresentacao, receitas_id)
				values ('Ben-U-Ron','Analg�sico', '0', '2030-02-15', 'Comprimido', '1');
insert into MEDICAMENTO (medicamento_designacao, medicamneto_descricao, medicamento_comparticipado, medicamento_validade, medicamento_apresentacao, receitas_id)
				values ('Pregabalina','Ansiol�tico', '1', '2028-07-03', 'Comprimido', '2');
insert into MEDICAMENTO (medicamento_designacao, medicamneto_descricao, medicamento_comparticipado, medicamento_validade, medicamento_apresentacao)	
				values ('Brufen', 'Anti-Inflamat�rio', '0', '2026-01-24', 'Xarope');
insert into MEDICAMENTO (medicamento_designacao, medicamneto_descricao, medicamento_comparticipado, medicamento_validade, medicamento_apresentacao)	
				values ('Nutradeica','Hidrata��o Cut�nea', '1', '2030-07-25', 'Creme');
insert into MEDICAMENTO (medicamento_designacao, medicamneto_descricao, medicamento_comparticipado, medicamento_validade, medicamento_apresentacao, receitas_id)	
				values ('Omeprazol','Revestimento Gastrico', '1', '2031-02-28', 'Comprimido', '2');
insert into MEDICAMENTO (medicamento_designacao, medicamneto_descricao, medicamento_comparticipado, medicamento_validade, medicamento_apresentacao, receitas_id)	
				values ('BiResp','Broncodilator', '0', '2025-02-25', 'Xarope', '10');
insert into MEDICAMENTO (medicamento_designacao, medicamneto_descricao, medicamento_comparticipado, medicamento_validade, medicamento_apresentacao)	
				values ('Bephantol','Hidratrante', '0', '2027-11-25', 'Creme');



--FARMACIA
insert into FARMACIA (farmacia_nome, farmacia_morada, farmacia_telefone)
			  values ('MedicamentosAli', 'R S�o Sebasti�o 32', '212438850');
insert into FARMACIA (farmacia_nome, farmacia_morada, farmacia_telefone)
			  values ('MedicamentosAcola', ' Avenida Marqu�s Tomar 19', '212323395');
insert into FARMACIA (farmacia_nome, farmacia_morada, farmacia_telefone)
			  values ('MedicamentosJaAli', 'R Germana T�nger 94', '212957784');
insert into FARMACIA (farmacia_nome, farmacia_morada, farmacia_telefone)
			  values ('MedicamentosAoLado', ' Avenida For�as Armadas 26', '212656436');
insert into FARMACIA (farmacia_nome, farmacia_morada, farmacia_telefone)
			  values ('MedicamentosAqui', 'Avenida J�lio Dinis 36', '212445236');



--STOCK						
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('1', '1', '240');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('1', '2', '145');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('1', '3', '30');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('1', '4', '405');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('1', '5', '35');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('1', '9', '35');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('2', '1', '40');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('2', '2', '45');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('2', '3', '05');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('2', '4', '55');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('2', '5', '135');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('2', '9', '185');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('3', '1', '30');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('3', '2', '400');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('3', '3', '202');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('3', '4', '105');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('3', '5', '235');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('4', '1', '340');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('4', '6', '245');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('4', '3', '150');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('4', '4', '05');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('4', '5', '135');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('4', '8', '340');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('4', '10', '245');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('4', '8', '150');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('4', '9', '135');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('5', '1', '140');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('5', '2', '345');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('5', '3', '150');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('5', '6', '205');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('5', '5', '135');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('5', '1', '140');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('5', '2', '345');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('5', '3', '150');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('5', '7', '205');
insert into STOCK (farmacia_id, medicamento_id, stock_quantidade)	
						values ('5', '5', '135');

						

--LAB  
insert into LAB (lab_nome, medicamento_id)
		values ('Bayer', '1');
insert into LAB (lab_nome, medicamento_id)
		values ('Pfizer', '2');
insert into LAB (lab_nome, medicamento_id)
		values ('Ipsen', '3');
insert into LAB (lab_nome, medicamento_id)
		values ('SYNLAB', '4');
insert into LAB (lab_nome, medicamento_id)
		values ('Gilead Sciences', '5');
insert into LAB (lab_nome, medicamento_id)
		values ('Bluepharma', '6');
insert into LAB (lab_nome, medicamento_id)
		values ('Havione', '7');
insert into LAB (lab_nome, medicamento_id)
		values ('AstraZeneca', '8');
insert into LAB (lab_nome, medicamento_id)
		values ('Biogen', '9');
insert into LAB (lab_nome, medicamento_id)
		values ('Eisai', '10');
